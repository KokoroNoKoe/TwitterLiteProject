/**
 * This class is a driver class with main method.
 * Please, use this class to start the program.
 *
 * @author Yuki Yamada
 * @author Aleix Molla
 * @version 2018/03/30
 */
public class TestDriver {
    /**
     * The first starting method to be called.
     * @param args
     */
    public static void main(String[]args){
        AdminController adminController = AdminController.getInstance();
    }
}
